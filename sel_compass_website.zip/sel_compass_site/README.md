# The SEL Compass — educator resource website

This is a complete, responsive, accessible, single-page educator website for a social-emotional learning assignment. **Only `index.html` is required**: styles, interactive activities, and graphics are embedded directly in the file. No paid account, external library, or extra asset files are needed.

## Preview

Double-click `index.html` to open the website in a desktop browser. Use the age-group buttons to switch between the six classroom activities. The page also works on phones.

## Publish on GitHub Pages (free)

1. Sign into [GitHub](https://github.com/) or create a free account.
2. Create a **public** repository (for example, `sel-compass`).
3. Choose **Add file → Upload files** and upload `index.html` at the root of the repository. Commit the upload.
4. Go to **Settings → Pages**. Under **Build and deployment**, set **Source: Deploy from a branch**; choose the `main` branch and `/ (root)` folder; save.
5. Once published, your link will be `https://YOUR-USERNAME.github.io/sel-compass/` (substitute your GitHub username and repository name). GitHub may take several minutes to publish.
6. Submit that published URL with the assignment.

Official documentation: https://docs.github.com/en/pages/quickstart

## Customize

- Change the `<title>` and heading in `index.html` to add your class or project name.
- Change colors in the `:root` CSS at the top of `index.html`.
- Edit the activities, family practices, or resources directly in the HTML.

## Contents

- Why social-emotional learning matters
- Prenatal development, prenatal care, and early childhood influences on adolescence
- Social/emotional milestones for early childhood (3–8), middle childhood (8–11), and adolescence (12–18)
- Two classroom SEL activities for each stage, with implementation instructions and virtual adaptations
- Definition, examples, and three teacher self-regulation models
- Age-specific home strategies for families
- Adolescent safety, including suicide and self-harm warning signs and response
- Three APA 7th peer-reviewed references and supplemental guidance links

**Note:** Publishing to a live URL requires access to your GitHub account; the HTML is already complete and ready to upload. Github Pages sites are public. Do not add private student information.
